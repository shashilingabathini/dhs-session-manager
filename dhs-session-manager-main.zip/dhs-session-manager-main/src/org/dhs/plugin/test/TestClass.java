package org.dhs.plugin.test;

import org.apache.log4j.Logger;
import org.dhs.plugin.util.APIUtil;

public class TestClass {

    private static Logger logger = Logger.getLogger(TestClass.class);

    public static void main(String[] args) {
        APIUtil  apiUtil  = new APIUtil("https://workplace-qa.customfleet.org/wsi/FNCEWS40MTOM","svc-fnbootsa-QA","7f|9cib!tV3h%0AM","FileNetP8WSI", "BAWStore");
        try {
           // apiUtil.addSessionManager();
            boolean isSessionManager  = apiUtil.getSessionManager();
            System.out.println(isSessionManager);
            logger.info("sample");
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
