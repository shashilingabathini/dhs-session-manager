require([
        "dojo/_base/lang",
        "ecm/model/Desktop",
        "dojo/aspect",
        "ecm/model/Request",
        "ecm/widget/dialog/MessageDialog"
    ],
    function(lang, Desktop , aspect , Request, MessageDialog) {
        // check the login session when user click on login ..
        var userId  = null;
        aspect.after(Desktop,"onLogin", lang.hitch(this,function() {
            // check if a user is already logged in
            userId = ecm.model.desktop.userId; // maintain an instance of it
            var params = {
                "userId" : ecm.model.desktop.userId,
                "type" : "GetSession"
            };
            Request.invokePluginService("DHSSessionManagerPlugin","ManagerService",{
                requestParams: params,
                requestCompleteCallback : lang.hitch(this,function(d) {
                    if(d && (d.status === "Success"  && d.isLogged === "T")) {
                        // already loggedIn so needs to show message box
                        var message = new MessageDialog({
                            text : 'We observed an active session already available with your id. <br> for more details please contact admin <br> <b>Note: </b> Only one session allowed per user',
                            buttonLabel : 'Cancel'
                        });

                        message.addButton('Ok' , lang.hitch(this,function() {
                            // need to logout desktop repo and reload
                            ecm.model.desktop.logoff(true); // this will invoke onLogout
                        }),false);

                        message.show();
                    }
                }),
                requestFailedCallback : lang.hitch(this,function(d) {
                    if(d && d.status === "Failed") {
                        // show error message & do immediate logout
                         var message = new MessageDialog({
                                text : 'An error occurred while creating a session object. However you can continue to work (but session is not managed by system)',
                                buttonLabel : 'Ok'
                         });
                         message.show();
                    }
                })
            });

        }));

        aspect.after(Desktop,"onLogout" , lang.hitch(this,function() {
                var params = {
                    userId : userId != "" ? userId : ecm.model.desktop.userId
                    type: "DisableSession"
                };
                Request.invokePluginService("DHSSessionManagerPlugin","ManagerService", {
                      requestParams: params,
                      requestCompleteCallback : lang.hitch(this,function(d) {
                            console.log('session is removed onLogout');
                            console.dir(d);
                      }),
                      requestFailedCallback : lang.hitch(this,function(d) {
                            console.log('An error occurred while removing session onLogout');
                            console.dir(d);
                      })
                } );
        }));
    }
);