define([
		"dojo/_base/declare",
		"dijit/_TemplatedMixin",
		"dijit/_WidgetsInTemplateMixin",
		"ecm/widget/admin/PluginConfigurationPane",
		"dojo/json",
		"dojo/text!./templates/ConfigurationPane.html",
		"ecm/widget/HoverHelp", // in template
        "ecm/widget/ValidationTextBox" // in template
	],
	function(declare, _TemplatedMixin, _WidgetsInTemplateMixin, PluginConfigurationPane, dojoJson,template) {

        templateString: template,

		widgetsInTemplate: true,

		postCreate: function() {
			this.inherited(arguments);
		},
		load: function(callback) {
			if (this.configurationString) {
				try {
					var jsonConfig = dojoJson.parse(this.configurationString);
					this.url.set('value',jsonConfig.configuration[0].value);
					this.username.set('value',jsonConfig.configuration[1].value);
					this.password.set('value',jsonConfig.configuration[2].value);
					this.stanza.set('value',jsonConfig.configuration[3].value);
					this.osname.set('value',jsonConfig.configuration[4].value);
				} catch (e) {
					this.logError("load", "failed to load configuration: " + e.message);
				}
			}
		},
		_onFieldChange : function() {
			var configArray = [];
			var configString = {
				name: "url",
				value: this.url.get('value')
			};
			configArray.push(configString);

			configString = {
				name: "username",
				value: this.username.get('value')
			};
			configArray.push(configString);

			configString = {
				name: "password",
				value: this.password.get('value')
			};
			configArray.push(configString);

			configString = {
				name: "stanza",
				value: this.stanza.get('value')
			};
			configArray.push(configString);

			configString = {
				name: "osname",
				value: this.osname.get('value')
			};
			configArray.push(configString);

			var configJson = {
				"configuration" : configArray
			};

			this.configurationString = JSON.stringify(configJson);
			this.onSaveNeeded(true);

		},
		validate: function() {
			return true;
		}

	});
});
