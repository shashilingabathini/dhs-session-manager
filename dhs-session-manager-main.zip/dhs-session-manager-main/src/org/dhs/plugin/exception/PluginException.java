package org.dhs.plugin.exception;

public class PluginException extends  Exception {

    public PluginException() {
        super();
    }
    public PluginException(Exception e) {
        super(e);
    }
}
